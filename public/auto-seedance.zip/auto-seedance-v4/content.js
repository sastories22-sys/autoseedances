(() => {
  var MSG = {
    GET_STATE:"GET_STATE",STATE_UPDATE:"STATE_UPDATE",START_QUEUE:"START_QUEUE",
    PAUSE_QUEUE:"PAUSE_QUEUE",RESUME_QUEUE:"RESUME_QUEUE",STOP_QUEUE:"STOP_QUEUE",
    SKIP_CURRENT:"SKIP_CURRENT",CLEAR_QUEUE:"CLEAR_QUEUE",LOG:"LOG",
    PROGRESS:"PROGRESS",DONE:"GENERATION_DONE",FAIL:"GENERATION_FAILED",
    DL_URL:"DOWNLOAD_URL",DL_B64:"DOWNLOAD_B64"
  };

  var promptId = null;
  var monTimer = null;
  var genStart = null;
  var lastKnownMediaUrls = new Set();

  // Guard: only register once per page load
  if (!window.__autoSeedanceListenerRegistered) {
    window.__autoSeedanceListenerRegistered = true;
    chrome.runtime.onMessage.addListener((msg, _, cb) => {
      if (msg.type !== "INJECT_PROMPT") return false;
      promptId = msg.promptId;
      clearMon();
      run(msg).then(() => cb({ ok: true })).catch((e) => { fail(e.message); cb({ ok: false }); });
      return true;
    });
  }

  // ── MAIN ──────────────────────────────────────────────────────────────────────
  async function run({ mode, text, images, settings }) {
    dbg(`▶ mode=${mode} "${text.substring(0,40)}..."`);
    lastKnownMediaUrls = snapshotMediaUrls();

    // S1: Navigate sidebar (AI Video / AI Image)
    await navigateSidebar(mode);
    await sleep(1500);
    dbg("S1 ✅ sidebar");

    // S2: Wait for prompt box
    const ready = await waitFor(() => !!getInputBox(), 20000);
    if (!ready) { fail("S2: UI not loaded"); return; }
    await sleep(800);
    dbg("S2 ✅ UI ready");

    // S3: Apply settings
    if (settings) {
      await applySettings(mode, settings);
      await sleep(600);
    }
    dbg("S3 ✅ settings");

    // S4: Upload image (i2v)
    if (mode === "i2v" && images?.length) {
      await uploadRefImage(images[0]);
      await sleep(2000);
      dbg("S4 ✅ image");
    }

    // S5: Inject prompt
    const injected = await injectText(text);
    if (!injected) { fail("S5: inject failed"); return; }
    await sleep(500);
    dbg("S5 ✅ prompt");

    // S6: Click generate
    const clicked = await clickGenerate();
    if (!clicked) { fail("S6: generate not found"); return; }
    dbg("S6 ✅ generate");

    await sleep(2000);
    genStart = Date.now();
    startMonitor(settings, mode);
  }

  // ── SIDEBAR NAVIGATION ────────────────────────────────────────────────────────
  // From debug: SPAN class="lv-select-view-selector" text="ai video"
  // Also SPAN class="lv-select-view-value" text="ai video"
  async function navigateSidebar(mode) {
    const isVideo = ["t2v","i2v"].includes(mode);
    const target = isVideo ? "ai video" : "ai image";
    dbg(`  nav → "${target}"`);

    // The sidebar uses a custom select: class contains "lv-select-view-selector" or "lv-select-view-value"
    // First check if already on correct section
    for (const el of document.querySelectorAll('[class*="lv-select-view"]')) {
      const t = (el.textContent || "").trim().toLowerCase();
      if (t === target) {
        dbg("  already on correct section");
        return true;
      }
    }

    // Click the sidebar selector to open dropdown
    const selectorSels = [
      '[class*="lv-select-view-selector"]',
      '[class*="lv-select-single"]',
      '[class*="toolbar-se"]',
      '[class*="sidebar"]',
      '[class*="nav-select"]'
    ];

    for (const sel of selectorSels) {
      for (const el of document.querySelectorAll(sel)) {
        if (!isVis(el)) continue;
        const t = (el.textContent || "").toLowerCase();
        if (t.includes("ai video") || t.includes("ai image") || t.includes("ai agent")) {
          el.click();
          await sleep(500);
          // Pick option
          const found = await pickOption(target);
          if (found) { dbg(`  ✅ nav: "${target}"`); return true; }
          document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          await sleep(200);
        }
      }
    }

    // Direct link/span click
    for (const el of document.querySelectorAll("a,span,li,button,[role='option'],[role='menuitem']")) {
      if (!isVis(el)) continue;
      const t = (el.textContent || "").trim().toLowerCase();
      if (t === target) {
        el.click();
        dbg(`  ✅ nav direct: "${target}"`);
        return true;
      }
    }

    dbg("  ⚠️ sidebar nav failed, continuing");
    return false;
  }

  // ── SETTINGS ──────────────────────────────────────────────────────────────────
  async function applySettings(mode, s) {
    const isVideo = ["t2v","i2v"].includes(mode);
    if (isVideo) {
      if (s.videoModel && s.videoModel !== "auto") {
        await setModel(s.videoModel);
        await sleep(500);
      }
      if (s.aspectRatio && s.aspectRatio !== "auto") {
        await setRatio(s.aspectRatio);
        await sleep(300);
      }
      if (s.duration && s.duration !== "auto") {
        await setDuration(String(s.duration));
        await sleep(300);
      }
    } else {
      if (s.imageModel && s.imageModel !== "auto") {
        await setModel(s.imageModel);
        await sleep(500);
      }
      if (s.aspectRatio && s.aspectRatio !== "auto") {
        await setRatio(s.aspectRatio);
        await sleep(300);
      }
    }
  }

  // Model: from debug → DIV class="lv-select lv-select-single lv-select-size-default toolbar-se"
  // Contains text "dreamina seedance 2.0 fast"
  async function setModel(modelName) {
    // Skip if auto selected
    if (!modelName || modelName === "auto" || modelName.startsWith("auto")) {
      dbg("  setModel: skipped (auto)");
      return false;
    }
    const lo = modelName.toLowerCase().trim();
    dbg(`  setModel: "${modelName}"`);

    // Find the model dropdown (lv-select with seedance/seedream text)
    const dropdownSels = [
      '[class*="lv-select"][class*="toolbar"]',
      '[class*="lv-select-single"]',
      '[class*="toolbar-se"]',
      '[class*="model-select"]',
      '[class*="lv-select"]'
    ];

    for (const sel of dropdownSels) {
      for (const el of document.querySelectorAll(sel)) {
        if (!isVis(el)) continue;
        const t = (el.textContent || "").toLowerCase();
        if (t.includes("seedance") || t.includes("seedream") || t.includes("fast") || t.includes("pro")) {
          el.click();
          await sleep(600);
          const found = await pickOption(lo);
          if (found) { dbg(`  ✅ model: "${modelName}"`); return true; }
          document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
          await sleep(300);
        }
      }
    }

    dbg(`  ⚠️ model not set: "${modelName}"`);
    return false;
  }

  // Ratio: from debug → SPAN class="button-text-sNFEGg" text="16:9"
  async function setRatio(ratio) {
    dbg(`  setRatio: "${ratio}"`);

    // Strategy 1: span[class*="button-text"] containing exact ratio
    for (const el of document.querySelectorAll('span[class*="button-text"]')) {
      if (!isVis(el)) continue;
      const t = (el.textContent || "").trim();
      if (t === ratio) {
        const btn = el.closest("button") || el.parentElement;
        if (btn) { btn.click(); await sleep(200); dbg(`  ✅ ratio via button-text: "${ratio}"`); return true; }
        el.click(); await sleep(200); return true;
      }
    }

    // Strategy 2: any button whose text is exactly the ratio (e.g. "16:9")
    for (const el of document.querySelectorAll("button")) {
      if (!isVis(el)) continue;
      const t = (el.textContent || "").trim();
      if (t === ratio || t === ratio.replace(":",":")) {
        el.click(); await sleep(200);
        dbg(`  ✅ ratio via button: "${ratio}"`); return true;
      }
    }

    // Strategy 3: any span/div with exact ratio text, small width
    for (const el of document.querySelectorAll("span,div,[role='radio'],[role='option']")) {
      if (!isVis(el)) continue;
      const t = (el.textContent || "").trim();
      if (t === ratio) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.width < 160) {
          const btn = el.closest("button") || el;
          btn.click(); await sleep(200);
          dbg(`  ✅ ratio fallback: "${ratio}"`); return true;
        }
      }
    }

    // Strategy 4: look for ratio group container, then click child matching ratio
    const ratioContainers = document.querySelectorAll('[class*="ratio"],[class*="aspect"],[class*="proportion"]');
    for (const container of ratioContainers) {
      if (!isVis(container)) continue;
      for (const child of container.querySelectorAll("button,span,[role='radio']")) {
        if (!isVis(child)) continue;
        if ((child.textContent||"").trim() === ratio) {
          child.click(); await sleep(200);
          dbg(`  ✅ ratio in container: "${ratio}"`); return true;
        }
      }
    }

    dbg(`  ⚠️ ratio not found: "${ratio}"`);
    return false;
  }

  // Duration: same pill button pattern as ratio
  async function setDuration(dur) {
    const target = dur.endsWith("s") ? dur : dur + "s";
    dbg(`  setDuration: "${target}"`);

    for (const el of document.querySelectorAll('span[class*="button-text"]')) {
      if (!isVis(el)) continue;
      const t = (el.textContent || "").trim().toLowerCase();
      if (t === target.toLowerCase() || t === dur.toLowerCase()) {
        const btn = el.closest("button") || el.parentElement;
        if (btn) { btn.click(); dbg(`  ✅ duration via button-text: "${target}"`); return true; }
        el.click();
        return true;
      }
    }

    // Fallback
    for (const el of document.querySelectorAll("button,span,div,[role='radio']")) {
      if (!isVis(el)) continue;
      const t = (el.textContent || "").trim();
      if (t === target || t === dur) {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.width < 120) {
          el.click();
          dbg(`  ✅ duration fallback: "${target}"`);
          return true;
        }
      }
    }

    dbg(`  ⚠️ duration not found: "${target}"`);
    return false;
  }

  // Generic: pick option from open dropdown/menu by text match
  async function pickOption(lo) {
    await sleep(300);
    const sels = [
      '[class*="lv-select-option"]',
      '[class*="lv-option"]',
      '[role="option"]',
      '[role="menuitem"]',
      '[class*="option-item"]',
      '[class*="select-item"]',
      '[class*="dropdown-item"]',
      'li'
    ];
    for (const sel of sels) {
      for (const el of document.querySelectorAll(sel)) {
        if (!isVis(el)) continue;
        const t = (el.textContent || "").trim().toLowerCase();
        if (t === lo || t.includes(lo) || lo.includes(t.split("\n")[0].trim())) {
          el.click();
          await sleep(200);
          return true;
        }
      }
    }
    return false;
  }

  // ── IMAGE UPLOAD (i2v) ────────────────────────────────────────────────────────
  async function uploadRefImage(fd) {
    // Check if image already uploaded (avoid double upload)
    const alreadyHasImage = document.querySelector(
      '[class*="reference-upload"] img, [class*="reference-item"] img, [class*="reference-group"] img[src*="blob"], [class*="reference-group"] img[src*="data:"]'
    );
    if (alreadyHasImage) {
      dbg("  image already in reference zone, skipping upload");
      return true;
    }

    const file = await toFile(fd);
    dbg("  uploadRefImage via drag-drop...");

    const zoneSels = [
      '[class*="reference-upload"]',
      '[id*="reference-upload"]',
      '[class*="reference-item"]',
      '[class*="reference-group-content"]',
      '[class*="reference-group"]'
    ];

    let dropZone = null;
    for (const sel of zoneSels) {
      for (const el of document.querySelectorAll(sel)) {
        if (!isVis(el)) continue;
        dropZone = el;
        dbg("  dropzone: " + sel);
        break;
      }
      if (dropZone) break;
    }

    if (dropZone) {
      await dragDropFile(dropZone, file);
      return true;  // stop here always - one drop only
    }

    // Fallback only if no dropZone found
    const inputBox = getInputBox();
    if (inputBox) {
      const parent = inputBox.closest('[class*="main-content"],[class*="input-wrap"],[class*="editor"]') || inputBox.parentElement;
      if (parent) {
        await dragDropFile(parent, file);
        return true;
      }
    }

    dbg("  upload failed");
    return false;
  }

  async function dragDropFile(zone, file) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      const rect = zone.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const evOpts = { bubbles: true, cancelable: true, clientX: cx, clientY: cy, dataTransfer: dt };
      zone.dispatchEvent(new DragEvent("dragenter", evOpts));
      await sleep(100);
      zone.dispatchEvent(new DragEvent("dragover", evOpts));
      await sleep(100);
      zone.dispatchEvent(new DragEvent("drop", evOpts));
      await sleep(600);
      dbg("  drag-drop fired once");
      return true;
    } catch(e) {
      dbg("  drag-drop error: " + e.message);
      return false;
    }
  }


  async function injectFile(inp, file) {
    const dt = new DataTransfer();
    dt.items.add(file);
    Object.defineProperty(inp, "files", { value: dt.files, configurable: true });
    inp.dispatchEvent(new Event("change", { bubbles: true }));
    inp.dispatchEvent(new Event("input", { bubbles: true }));
    await sleep(500);
  }

  // ── PROMPT INPUT ──────────────────────────────────────────────────────────────
  // From debug: DIV class="tiptap ProseMirror" (contenteditable)
  function getInputBox() {
    // Primary: tiptap ProseMirror (exact from debug output)
    for (const el of document.querySelectorAll('[class*="ProseMirror"],[class*="tiptap"]')) {
      if (isVis(el) && el.isContentEditable) return el;
    }
    // Fallback textarea
    const sels = [
      'textarea[placeholder*="prompt" i]','textarea[placeholder*="describe" i]',
      'textarea[placeholder*="Start" i]','textarea[placeholder*="idea" i]',
      'textarea','[contenteditable="true"]'
    ];
    for (const s of sels) {
      for (const el of document.querySelectorAll(s)) {
        if (isVis(el) && el.offsetHeight > 20) return el;
      }
    }
    return null;
  }

  async function injectText(text) {
    const el = getInputBox();
    if (!el) return false;
    try {
      el.focus();
      await sleep(200);
      if (el.isContentEditable) {
        // ProseMirror clear: force innerHTML wipe first, then insertText
        el.focus();
        await sleep(100);
        // Force clear all paragraphs inside ProseMirror
        el.querySelectorAll("p,div,span").forEach(child => { child.innerHTML = ""; });
        // Also clear the element itself
        const p = el.querySelector("p");
        if (p) p.textContent = "";
        else el.textContent = "";
        await sleep(80);
        // Verify empty
        if ((el.textContent||"").trim().length > 0) {
          el.innerHTML = "<p></p>";
          await sleep(50);
        }
        // Insert fresh text
        el.focus();
        // Move cursor to end
        const range = document.createRange();
        range.selectNodeContents(el);
        range.collapse(false);
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand("insertText", false, text);
        el.dispatchEvent(new InputEvent("input", { bubbles: true, data: text }));
        await sleep(300);
        return (el.textContent?.trim().length || 0) > 0;
      } else {
        const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) setter.call(el, ""); else el.value = "";
        el.dispatchEvent(new Event("input", { bubbles: true }));
        await sleep(100);
        if (setter) setter.call(el, text); else el.value = text;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        await sleep(300);
        return (el.value?.length || 0) > 0;
      }
    } catch(e) { dbg("inject err: "+e.message); return false; }
  }

  // ── GENERATE BUTTON ───────────────────────────────────────────────────────────
  // From debug: SVG-circle class="lv-btn lv-btn-primary lv-btn-size-default lv-btn-shape-circl" w=36
  async function clickGenerate() {
    // Primary: lv-btn-primary circle button (exact from debug)
    for (const el of document.querySelectorAll('[class*="lv-btn-primary"]')) {
      if (!isVis(el)) continue;
      const r = el.getBoundingClientRect();
      // Circle button: width ~36px
      if (r.width >= 28 && r.width <= 60 && Math.abs(r.width - r.height) < 15) {
        doClick(el, "lv-btn-primary-circle");
        return true;
      }
    }

    // Secondary: lv-btn-secondary circle (also seen in debug)
    for (const el of document.querySelectorAll('[class*="lv-btn-secondary"],[class*="lv-btn-squ"]')) {
      if (!isVis(el)) continue;
      const r = el.getBoundingClientRect();
      if (r.width >= 28 && r.width <= 60) {
        // Make sure it's near the input box
        const inp = getInputBox();
        if (inp) {
          const ir = inp.getBoundingClientRect();
          const dist = Math.hypot(r.left - ir.right, r.top - ir.bottom);
          if (dist < 300) { doClick(el, "lv-btn-secondary-circle"); return true; }
        }
      }
    }

    // Fallback: any SVG circle button near input
    const inputBox = getInputBox();
    const allBtns = [...document.querySelectorAll("button:not([disabled])")].filter(isVis);
    const circleBtns = allBtns.filter(b => {
      const r = b.getBoundingClientRect();
      return b.querySelector("svg") && r.width >= 28 && r.width <= 90 && Math.abs(r.width - r.height) < 15;
    });
    if (circleBtns.length && inputBox) {
      const ir = inputBox.getBoundingClientRect();
      circleBtns.sort((a, b) => {
        const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
        return Math.hypot(ra.left - ir.right, ra.top - ir.bottom) - Math.hypot(rb.left - ir.right, rb.top - ir.bottom);
      });
      doClick(circleBtns[0], "circle-svg-fallback");
      return true;
    }

    return false;
  }

  // ── MONITOR / DOWNLOAD ────────────────────────────────────────────────────────
  function startMonitor(settings, mode) {
    clearMon();
    const isVid = ["t2v","i2v"].includes(mode);
    let stableCount = 0;
    let genConfirmed = false;
    let noProgressCount = 0;

    monTimer = setInterval(async () => {
      const elapsed = Math.round((Date.now() - genStart) / 1000);
      chrome.runtime.sendMessage({ type: MSG.PROGRESS, msg: `⏳ ${elapsed}s — waiting for ${isVid?"video":"image"}...`, elapsed }).catch(()=>{});

      if (!genConfirmed && isGenerating()) { genConfirmed = true; dbg(`  ✅ generating at ${elapsed}s`); }

      const newUrls = findNewMedia(mode);
      if (newUrls.length > 0) {
        stableCount++;
        if (stableCount >= 2) {
          clearMon();
          await sleep(500);
          const bestUrl = pickBestUrl(newUrls, isVid);
          if (bestUrl) await downloadByUrl(bestUrl, settings, mode);
          else await triggerDownload(settings, mode);
          await sleep(1000);
          chrome.runtime.sendMessage({ type: MSG.DONE, promptId }).catch(()=>{});
          return;
        }
      } else { stableCount = 0; }

      const dlBtn = findDownloadBtn();
      if (dlBtn) {
        stableCount++;
        if (stableCount >= 2) {
          clearMon();
          await sleep(400);
          await triggerDownload(settings, mode);
          await sleep(1000);
          chrome.runtime.sendMessage({ type: MSG.DONE, promptId }).catch(()=>{});
          return;
        }
      }

      if (elapsed > 30 && !isGenerating() && genConfirmed) {
        noProgressCount++;
        hoverCards();
        if (noProgressCount >= 4) {
          const nu = findNewMedia(mode);
          const db = findDownloadBtn();
          clearMon();
          if (db) await triggerDownload(settings, mode);
          else if (nu.length) { const u = pickBestUrl(nu, isVid); if (u) await downloadByUrl(u, settings, mode); }
          await sleep(1000);
          chrome.runtime.sendMessage({ type: MSG.DONE, promptId }).catch(()=>{});
          return;
        }
      }

      if (elapsed > 720) { clearMon(); fail("Timeout 12min"); }
    }, 3000);
  }

  function snapshotMediaUrls() {
    const urls = new Set();
    document.querySelectorAll("img[src],video[src]").forEach(el => { if (el.src?.startsWith("http")) urls.add(el.src); });
    document.querySelectorAll("video source[src]").forEach(el => { if (el.src?.startsWith("http")) urls.add(el.src); });
    return urls;
  }

  function findNewMedia(mode) {
    const isVid = ["t2v","i2v"].includes(mode);
    const current = snapshotMediaUrls();
    const newUrls = [];
    for (const url of current) {
      if (lastKnownMediaUrls.has(url)) continue;
      // Skip UI assets
      if (/avatar|icon|logo|favicon|sprite|profile|head|login|neutral|capcut-web-login/.test(url)) continue;
      if (isVid) {
        if (url.includes(".mp4") || url.includes("video") || url.includes("mp4")) newUrls.unshift(url);
        else newUrls.push(url);
      } else {
        if (url.includes("thumbnail") || url.includes("_xs") || url.includes("_mini")) continue;
        newUrls.push(url);
      }
    }
    return newUrls;
  }

  function pickBestUrl(urls, isVid) {
    if (!urls.length) return null;
    if (isVid) return urls.find(u => u.includes(".mp4")||u.includes("mp4")||u.includes("video")) || urls[0];
    return urls.find(u => (u.includes(".jpg")||u.includes(".png")||u.includes(".webp"))&&!u.includes("thumbnail")) || urls[0];
  }

  async function downloadByUrl(url, settings, mode) {
    const proj = (settings?.projectName || "My-Project").replace(/[^a-zA-Z0-9_\- ]/g,"_");
    const isVid = ["t2v","i2v"].includes(mode);
    const ext = isVid ? "mp4" : (url.includes(".png")?"png":url.includes(".webp")?"webp":"jpg");
    const fn = `Auto-Seedance/${proj}/dreamina_${mode}_${Date.now()}.${ext}`;
    if (url.startsWith("blob:")) {
      try {
        const blob = await (await fetch(url)).blob();
        const b64 = await blobToB64(blob);
        chrome.runtime.sendMessage({ type: MSG.DL_B64, b64, filename: fn, mime: blob.type }).catch(()=>{});
        dbg(`  DL blob → ${fn}`); return;
      } catch(e) { dbg("blob fail: "+e.message); }
    }
    chrome.runtime.sendMessage({ type: MSG.DL_URL, url, filename: fn }).catch(()=>{});
    dbg(`  DL url → ${fn}`);
  }

  async function triggerDownload(settings, mode) {
    hoverCards();
    await sleep(600);
    const dlBtn = findDownloadBtn();
    if (!dlBtn) { dbg("  no dl btn"); return; }
    const proj = (settings?.projectName || "My-Project").replace(/[^a-zA-Z0-9_\- ]/g,"_");
    const isVid = ["t2v","i2v"].includes(mode);
    const fn = `Auto-Seedance/${proj}/dreamina_${mode}_${Date.now()}.${isVid?"mp4":"jpg"}`;
    dlBtn.click();
    await sleep(800);
    const nu = findNewMedia(mode);
    if (nu.length) {
      const url = pickBestUrl(nu, isVid);
      if (url) chrome.runtime.sendMessage({ type: MSG.DL_URL, url, filename: fn }).catch(()=>{});
    }
  }

  function findDownloadBtn() {
    // lv-btn with download aria-label
    for (const el of document.querySelectorAll('[class*="lv-btn"],[aria-label*="download" i],[title*="download" i],[class*="download"],[class*="Download"]')) {
      if (!isVis(el)) continue;
      const lbl = (el.getAttribute("aria-label")||el.getAttribute("title")||"").toLowerCase();
      if (lbl.includes("download") || lbl.includes("save")) return el;
    }
    for (const el of document.querySelectorAll('button,a,[role="button"]')) {
      if (!isVis(el)) continue;
      const lbl = (el.getAttribute("aria-label")||el.getAttribute("title")||el.textContent||"").toLowerCase().trim();
      if (lbl === "download" || lbl === "下载" || lbl === "save") return el;
    }
    return null;
  }

  function hoverCards() {
    for (const sel of ['[class*="result"]','[class*="output"]','[class*="generated"]','[class*="history-item"]','[class*="work-item"]','[class*="card"]']) {
      for (const el of document.querySelectorAll(sel)) {
        if (!isVis(el)) continue;
        el.dispatchEvent(new MouseEvent("mouseover",{bubbles:true}));
        el.dispatchEvent(new MouseEvent("mouseenter",{bubbles:true}));
      }
    }
  }

  function isGenerating() {
    return ['[class*="lv-loading"]','[class*="loading"]','[class*="progress"]','[class*="generating"]','[class*="spinner"]','[class*="waiting"]']
      .some(s => { const el = document.querySelector(s); return el && isVis(el); });
  }

  function clearMon() { if (monTimer) { clearInterval(monTimer); monTimer = null; } }

  function doClick(el, why) {
    el.scrollIntoView({ block: "nearest" });
    el.dispatchEvent(new MouseEvent("mouseover",{bubbles:true}));
    el.dispatchEvent(new MouseEvent("mousedown",{bubbles:true,cancelable:true}));
    el.dispatchEvent(new MouseEvent("mouseup",{bubbles:true,cancelable:true}));
    el.click();
    dbg(`  ✅ click[${why}]: ${(el.className||el.tagName).substring(0,50)}`);
  }

  async function toFile(fd) {
    const res = await fetch(`data:${fd.mimeType};base64,${fd.data}`);
    const blob = await res.blob();
    return new File([blob], fd.name, { type: fd.mimeType });
  }

  function blobToB64(blob) {
    return new Promise(r => { const fr = new FileReader(); fr.onload = e => r(e.target.result.split(",")[1]); fr.readAsDataURL(blob); });
  }

  function waitFor(fn, ms = 15000) {
    return new Promise(res => {
      const end = Date.now() + ms;
      const t = setInterval(() => {
        if (fn()) { clearInterval(t); res(true); }
        else if (Date.now() > end) { clearInterval(t); res(false); }
      }, 500);
    });
  }

  function isVis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none" && s.opacity !== "0";
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function dbg(m) {
    console.log("[AS]", m);
    chrome.runtime.sendMessage({ type: MSG.PROGRESS, msg: m, elapsed: 0 }).catch(()=>{});
  }

  function fail(r) {
    clearMon();
    console.error("[AS] FAIL:", r);
    chrome.runtime.sendMessage({ type: MSG.FAIL, promptId, reason: r }).catch(()=>{});
  }

  dbg("Content script ready ✅");
})();
