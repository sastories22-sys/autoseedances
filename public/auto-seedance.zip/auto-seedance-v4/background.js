// src/utils/msg.js
var MSG = {
  GET_STATE: "GET_STATE",
  STATE_UPDATE: "STATE_UPDATE",
  START_QUEUE: "START_QUEUE",
  PAUSE_QUEUE: "PAUSE_QUEUE",
  RESUME_QUEUE: "RESUME_QUEUE",
  STOP_QUEUE: "STOP_QUEUE",
  SKIP_CURRENT: "SKIP_CURRENT",
  CLEAR_QUEUE: "CLEAR_QUEUE",
  LOG: "LOG",
  PROGRESS: "PROGRESS",
  DONE: "GENERATION_DONE",
  FAIL: "GENERATION_FAILED",
  DL_URL: "DOWNLOAD_URL",
  DL_B64: "DOWNLOAD_B64"
};

// src/background/background.js
var DREAMINA = {
  t2i: "https://dreamina.capcut.com/ai-tool/image/generate",
  t2v: "https://dreamina.capcut.com/ai-tool/video/generate",
  i2v: "https://dreamina.capcut.com/ai-tool/video/generate",
  ingredients: "https://dreamina.capcut.com/ai-tool/video/generate"
};
var S = {
  status: "idle",
  queue: [],
  idx: 0,
  total: 0,
  current: null,
  settings: {},
  tabId: null
};
var port = null;
var lock = false;
chrome.action.onClicked.addListener((tab) => chrome.sidePanel.open({ tabId: tab.id }));
chrome.runtime.onInstalled.addListener(() => chrome.sidePanel.setOptions({ enabled: true }));
chrome.alarms.create("ka", { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(() => {
});
chrome.runtime.onConnect.addListener((p) => {
  if (p.name !== "sidebar")
    return;
  port = p;
  p.onDisconnect.addListener(() => port = null);
  push({ type: MSG.STATE_UPDATE, state: S });
});
chrome.runtime.onMessage.addListener((m, _, cb) => {
  handle(m).then(cb).catch((e) => cb({ ok: false, e: e.message }));
  return true;
});
async function handle(m) {
  switch (m.type) {
    case MSG.GET_STATE: {
      const logs = await cGet("logs") || [];
      const failed = await cGet("failed") || [];
      return { state: S, logs, failed };
    }
    case MSG.START_QUEUE:
      await startQueue(m.queue, m.settings);
      return { ok: true };
    case MSG.PAUSE_QUEUE:
      S.status = "paused";
      pushState();
      log("\u23F8 Paused", "warn");
      return { ok: true };
    case MSG.RESUME_QUEUE:
      if (S.status === "paused") {
        S.status = "running";
        pushState();
        log("\u25B6 Resumed", "info");
        next();
      }
      return { ok: true };
    case MSG.STOP_QUEUE:
      S.status = "stopped";
      S.current = null;
      lock = false;
      pushState();
      log("\u23F9 Stopped", "warn");
      return { ok: true };
    case MSG.SKIP_CURRENT: {
      const r = S.queue.find((p) => p.status === "running");
      if (r) {
        r.status = "skipped";
        log("\u23ED Skipped", "warn");
      }
      lock = false;
      next();
      return { ok: true };
    }
    case MSG.CLEAR_QUEUE:
      S = { ...S, queue: [], status: "idle", current: null, idx: 0, total: 0 };
      lock = false;
      pushState();
      return { ok: true };
    case MSG.DONE: {
      const p = S.queue.find((q) => q.id === m.promptId);
      if (p) {
        p.status = "done";
        S.idx++;
        log(`\u2705 Done [${S.idx}/${S.total}]: ${p.text.substring(0, 40)}...`, "success");
      }
      pushState();
      lock = false;
      await sleep(1500);
      next();
      return { ok: true };
    }
    case MSG.FAIL: {
      const p = S.queue.find((q) => q.id === m.promptId);
      if (p) {
        p.retries = (p.retries || 0) + 1;
        const max = S.settings.maxRetry || 3;
        if (p.retries <= max) {
          p.status = "pending";
          log(`\u{1F504} Retry ${p.retries}/${max}: ${p.text.substring(0, 40)}...`, "warn");
          lock = false;
          await sleep(4e3);
          next();
        } else {
          p.status = "failed";
          await saveFailed(p.text, m.reason || "Max retries");
          log(`\u274C Failed: ${p.text.substring(0, 40)} \u2014 ${m.reason}`, "error");
          push({ type: "PROMPT_FAILED", promptId: p.id, text: p.text, reason: m.reason });
          lock = false;
          await sleep(2e3);
          next();
        }
      }
      pushState();
      return { ok: true };
    }
    case MSG.PROGRESS:
      push({ type: MSG.PROGRESS, msg: m.msg, elapsed: m.elapsed });
      return { ok: true };
    case MSG.DL_URL:
      if (m.url) {
        const fn = m.filename || `${clean(S.settings.saveFolder || "Auto-Seedance")}/dreamina_${Date.now()}`;
        chrome.downloads.download({ url: m.url, filename: fn, saveAs: false }, (id) => {
          if (chrome.runtime.lastError)
            log(`\u26A0\uFE0F DL error: ${chrome.runtime.lastError.message}`, "warn");
          else
            log(`\u{1F4E5} Saved: ${fn}`, "success");
        });
      }
      return { ok: true };
    case MSG.DL_B64:
      if (m.b64) {
        const url = `data:${m.mime || "video/mp4"};base64,${m.b64}`;
        chrome.downloads.download({ url, filename: m.filename, saveAs: false });
        log(`\u{1F4E5} Saved: ${m.filename}`, "success");
      }
      return { ok: true };
    default:
      return { ok: false };
  }
}
async function startQueue(rawQueue, settings) {
  S.settings = settings;
  S.queue = rawQueue.map((item, i) => ({
    id: `p_${Date.now()}_${i}`,
    text: item.text,
    images: item.images || [],
    audio: item.audio || null,
    videoRef: item.videoRef || null,
    styleRef: item.styleRef || null,
    status: "pending",
    retries: 0
  }));
  S.total = S.queue.length;
  S.idx = 0;
  S.status = "running";
  lock = false;
  pushState();
  log(`\u{1F680} Queue: ${S.queue.length} prompts | mode: ${settings.mode}`, "info");
  next();
}
async function next() {
  if (lock || S.status !== "running")
    return;
  const pending = S.queue.filter((p) => p.status === "pending");
  if (!pending.length) {
    if (!S.queue.some((p) => p.status === "running")) {
      S.status = "idle";
      pushState();
      log("\u{1F389} All prompts completed!", "success");
      push({ type: "QUEUE_COMPLETE" });
    }
    return;
  }
  lock = true;
  const prompt = pending[0];
  prompt.status = "running";
  S.current = prompt;
  pushState();
  if (S.idx > 0) {
    const dMin = (S.settings.delayMin || 15) * 1e3;
    const dMax = (S.settings.delayMax || 25) * 1e3;
    const d = Math.floor(Math.random() * (dMax - dMin + 1)) + dMin;
    log(`\u23F1 Waiting ${Math.round(d / 1e3)}s before next...`, "info");
    await sleep(d);
  }
  if (S.status !== "running") {
    lock = false;
    return;
  }
  log(`\u2699\uFE0F [${S.idx + 1}/${S.total}] "${prompt.text.substring(0, 50)}..."`, "info");
  const mode = S.settings.mode;
  const targetUrl = DREAMINA[mode] || DREAMINA.t2i;
  try {
    S.tabId = await gotoUrl(targetUrl, S.tabId);
  } catch (e) {
    log(`\u274C Navigation error: ${e.message}`, "error");
    prompt.status = "pending";
    lock = false;
    await sleep(3e3);
    next();
    return;
  }
  await sleep(1800);
  let sent = false;
  for (let a = 1; a <= 3; a++) {
    try {
      // content.js already injected via manifest content_scripts
      await sleep(600);
      await chrome.tabs.sendMessage(S.tabId, {
        type: "INJECT_PROMPT",
        promptId: prompt.id,
        text: prompt.text,
        images: prompt.images,
        audio: prompt.audio,
        videoRef: prompt.videoRef,
        styleRef: prompt.styleRef,
        mode,
        settings: S.settings
      });
      sent = true;
      break;
    } catch (e) {
      log(`\u26A0\uFE0F Send attempt ${a}: ${e.message}`, "warn");
      await sleep(2e3);
    }
  }
  if (!sent) {
    prompt.status = "pending";
    prompt.retries = (prompt.retries || 0) + 1;
    lock = false;
    log("\u274C Content script unreachable", "error");
    await sleep(3e3);
    next();
    return;
  }
  setTimeout(() => {
    const p = S.queue.find((q) => q.id === prompt.id && q.status === "running");
    if (p) {
      p.status = "pending";
      p.retries = (p.retries || 0) + 1;
      lock = false;
      next();
    }
  }, 12 * 60 * 1e3);
}
async function gotoUrl(url, existId) {
  const host = new URL(url).hostname;
  if (existId) {
    try {
      const t = await chrome.tabs.get(existId);
      const th = t.url ? new URL(t.url).hostname : "";
      if (th === host) {
        if (!t.url.startsWith(url))
          await chrome.tabs.update(existId, { url });
        else
          await chrome.tabs.update(existId, { active: true });
        await waitLoad(existId);
        return existId;
      }
    } catch (e) {
    }
  }
  const all = await chrome.tabs.query({});
  const ex = all.find((t) => {
    try {
      return new URL(t.url).hostname === host;
    } catch (e) {
      return false;
    }
  });
  if (ex) {
    if (!ex.url.startsWith(url))
      await chrome.tabs.update(ex.id, { url, active: true });
    else
      await chrome.tabs.update(ex.id, { active: true });
    await waitLoad(ex.id);
    return ex.id;
  }
  log(`\u{1F4C2} Opening Dreamina tab...`, "info");
  const tab = await chrome.tabs.create({ url, active: true });
  await waitLoad(tab.id);
  return tab.id;
}
function waitLoad(tabId) {
  return new Promise((res) => {
    chrome.tabs.get(tabId, (t) => {
      if (t && t.status === "complete") {
        setTimeout(res, 2e3);
        return;
      }
      const to = setTimeout(() => res(), 2e4);
      function cb(id, info) {
        if (id !== tabId || info.status !== "complete")
          return;
        chrome.tabs.onUpdated.removeListener(cb);
        clearTimeout(to);
        setTimeout(res, 2500);
      }
      chrome.tabs.onUpdated.addListener(cb);
    });
  });
}
function push(m) {
  if (port)
    try {
      port.postMessage(m);
    } catch (e) {
    }
}
function pushState() {
  push({ type: MSG.STATE_UPDATE, state: S });
}
function clean(s) {
  return String(s).replace(/[^a-zA-Z0-9_\-]/g, "_");
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function cGet(k) {
  return new Promise((r) => chrome.storage.local.get(k, (d) => r(d[k])));
}
function cSet(o) {
  return new Promise((r) => chrome.storage.local.set(o, r));
}
async function log(message, type = "info") {
  const logs = await cGet("logs") || [];
  logs.unshift({ message, type, timestamp: Date.now() });
  if (logs.length > 300)
    logs.splice(300);
  await cSet({ logs });
  push({ type: MSG.LOG, message, logType: type });
}
async function saveFailed(prompt, reason) {
  const f = await cGet("failed") || [];
  f.unshift({ prompt, reason, timestamp: Date.now() });
  await cSet({ failed: f });
}
