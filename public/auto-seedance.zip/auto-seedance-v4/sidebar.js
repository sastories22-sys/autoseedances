(() => {
  // src/utils/msg.js
  var MSG = {
    GET_STATE: "GET_STATE",
    STATE_UPDATE: "STATE_UPDATE",
    START_QUEUE: "START_QUEUE",
    PAUSE_QUEUE: "PAUSE_QUEUE",
    RESUME_QUEUE: "RESUME_QUEUE",
    STOP_QUEUE: "STOP_QUEUE",
    SKIP_CURRENT: "SKIP_CURRENT",
    CLEAR_QUEUE: "CLEAR_QUEUE",
    LOG: "LOG",
    PROGRESS: "PROGRESS",
    DONE: "GENERATION_DONE",
    FAIL: "GENERATION_FAILED",
    DL_URL: "DOWNLOAD_URL",
    DL_B64: "DOWNLOAD_B64"
  };

  // src/sidebar/App.js
  // Dreamina actual UI options (from screenshots)
  var ASPECT_VIDEO = ["21:9", "16:9", "4:3", "1:1", "3:4", "9:16"];
  var ASPECT_IMAGE = ["21:9", "16:9", "4:3", "1:1", "3:4", "9:16"];
  var DURATIONS = ["4", "8", "5", "10"];
  var VIDEO_MODELS = [
    "auto (don't change)",
    "Dreamina Seedance 2.0 Fast",
    "Dreamina Seedance 2.0",
    "Dreamina Seedance 1.5 Pro",
    "Dreamina Seedance 1.0",
    "Dreamina Seedance 1.0 Fast"
  ];
  var IMAGE_MODELS = ["auto (don't change)", "Seedream 4.1", "Seedream 3.0", "Seedream 4.0"];
  // Only AI Video and AI Image (no audio/ingredients)
  var MODES = {
    t2v: { label: "Text \u2192 Video", icon: "\u{1F3AC}", isVideo: true, needImg: false },
    t2i: { label: "Text \u2192 Image", icon: "\u{1F5BC}", isVideo: false, needImg: false },
    i2v: { label: "Image \u2192 Video", icon: "\u{1F39E}", isVideo: true, needImg: true }
  };
  var App = class {
    constructor(root) {
      this.root = root;
      this.port = null;
      this.bgState = { status: "idle", queue: [], idx: 0, total: 0 };
      this.logs = [];
      this.failed = [];
      this.promptList = [];
      this.charImages = [];
      this.activeTab = "queue";
      this.cfg = {
        mode: "t2i",
        aspectRatio: "16:9",
        duration: "4",
        videoModel: "auto",
        imageModel: "Seedream 4.1",
        delayMin: 15,
        delayMax: 25,
        projectName: "My Project",
        maxRetry: 3
      };
    }
    async init() {
      const saved = await this.cGet("cfg");
      if (saved)
        this.cfg = { ...this.cfg, ...saved };
      this.renderSplash();
      setTimeout(() => this.renderMain(), 2400);
    }
    cGet(k) {
      return new Promise((r) => chrome.storage.local.get(k, (d) => r(d[k])));
    }
    cSet(o) {
      return new Promise((r) => chrome.storage.local.set(o, r));
    }
    msg(type, data = {}) {
      return new Promise((r) => chrome.runtime.sendMessage({ type, ...data }, (res) => r(res || {})));
    }
    q(s) {
      return this.root.querySelector(s);
    }
    qAll(s) {
      return this.root.querySelectorAll(s);
    }
    connectBg() {
      this.port = chrome.runtime.connect({ name: "sidebar" });
      this.port.onMessage.addListener((m) => this.onBg(m));
      this.port.onDisconnect.addListener(() => setTimeout(() => this.connectBg(), 1e3));
    }
    onBg(m) {
      switch (m.type) {
        case MSG.STATE_UPDATE:
          this.bgState = m.state;
          this.refreshRunBar();
          this.refreshQueueList();
          break;
        case MSG.LOG:
          this.logs.unshift({ message: m.message, type: m.logType, ts: Date.now() });
          if (this.logs.length > 300)
            this.logs.pop();
          if (this.activeTab === "logs")
            this.refreshLogs();
          break;
        case MSG.PROGRESS: {
          const el = this.q("#progText");
          if (el)
            el.textContent = m.msg;
          break;
        }
        case "PROMPT_FAILED":
          this.failed.unshift({ prompt: m.text, reason: m.reason, ts: Date.now() });
          if (this.activeTab === "failed")
            this.refreshFailed();
          this.updateFailBadge();
          break;
        case "QUEUE_COMPLETE":
          this.toast("\u{1F389} All done! Check Downloads folder.", "success");
          this.refreshRunBar();
          break;
      }
    }
    // ─── SPLASH ───────────────────────────────────────────────────────────────
    renderSplash() {
      this.root.innerHTML = `
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    *{box-sizing:border-box;margin:0;padding:0}
    body{background:#FAF8F5;font-family:'Inter',system-ui,sans-serif;overflow:hidden}
    .sp{height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;
      background:linear-gradient(160deg,#fff9f0 0%,#FAF8F5 60%,#fff0f3 100%)}
    .sp-logo{width:80px;height:80px;background:linear-gradient(135deg,#F59E0B,#FB7185);
      border-radius:24px;display:flex;align-items:center;justify-content:center;font-size:38px;
      box-shadow:0 8px 32px rgba(245,158,11,.3),0 2px 8px rgba(251,113,133,.2);
      animation:pop .6s cubic-bezier(.34,1.56,.64,1) both}
    @keyframes pop{from{opacity:0;transform:scale(.6) translateY(10px)}to{opacity:1;transform:scale(1) translateY(0)}}
    .sp-name{margin-top:20px;font-size:24px;font-weight:800;color:#1F2937;letter-spacing:-.5px;
      animation:up .5s .15s ease both}
    .sp-tag{margin-top:5px;font-size:11px;color:#9CA3AF;letter-spacing:.12em;text-transform:uppercase;font-weight:500;
      animation:up .5s .25s ease both}
    @keyframes up{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
    .sp-bar{margin-top:36px;width:180px;height:3px;background:#F3F4F6;border-radius:99px;overflow:hidden;
      animation:up .5s .35s ease both}
    .sp-fill{height:100%;background:linear-gradient(90deg,#F59E0B,#FB7185);border-radius:99px;
      animation:load 2.2s cubic-bezier(.4,0,.2,1) forwards}
    @keyframes load{from{width:0}to{width:100%}}
    .sp-ver{margin-top:14px;font-size:10px;color:#D1D5DB;animation:up .5s .45s ease both}
    </style>
    <div class="sp">
      <div class="sp-logo">\u{1F331}</div>
      <div class="sp-name">Auto Seedance</div>
      <div class="sp-tag">Dreamina Bulk Generator</div>
      <div class="sp-bar"><div class="sp-fill"></div></div>
      <div class="sp-ver">v1.0 \xB7 Powered by Dreamina</div>
    </div>`;
    }
    // ─── MAIN ─────────────────────────────────────────────────────────────────
    renderMain() {
      this.root.innerHTML = `<style>${CSS}</style><div class="app">${HTML}</div>`;
      this.connectBg();
      this.bindAll();
      this.applyModeUI();
      this.populateSettings();
      this.renderPromptList();
      this.renderCharImages();
      this.msg(MSG.GET_STATE).then((res) => {
        if (res.state)
          this.bgState = res.state;
        if (res.logs)
          this.logs = res.logs;
        if (res.failed)
          this.failed = res.failed;
        this.refreshAll();
      });
    }
    // ─── BIND ─────────────────────────────────────────────────────────────────
    bindAll() {
      this.qAll(".tab").forEach((t) => t.addEventListener("click", () => {
        this.activeTab = t.dataset.t;
        this.qAll(".tab").forEach((x) => x.classList.toggle("active", x === t));
        this.qAll(".pane").forEach((x) => x.classList.toggle("active", x.id === `p-${t.dataset.t}`));
        if (this.activeTab === "logs")
          this.refreshLogs();
        if (this.activeTab === "failed")
          this.refreshFailed();
      }));
      this.qAll(".mpill").forEach((p) => p.addEventListener("click", () => {
        this.cfg.mode = p.dataset.mode;
        this.qAll(".mpill").forEach((x) => x.classList.toggle("active", x === p));
        this.applyModeUI();
        this.saveCfg();
      }));
      this.q("#btnRun").addEventListener("click", () => this.doRun());
      this.q("#btnPause").addEventListener("click", () => this.doPause());
      this.q("#btnStop").addEventListener("click", () => this.doStop());
      this.q("#btnSkip").addEventListener("click", () => this.msg(MSG.SKIP_CURRENT));
      this.q("#btnClear").addEventListener("click", () => this.doClear());
      this.q("#btnOpen").addEventListener("click", () => {
        const u = { t2v: "https://dreamina.capcut.com/ai-tool/video/generate", t2i: "https://dreamina.capcut.com/ai-tool/image/generate", i2v: "https://dreamina.capcut.com/ai-tool/video/generate" };
        chrome.tabs.create({ url: u[this.cfg.mode] || u.t2i });
      });
      this.q("#btnAdd").addEventListener("click", () => this.addPrompts());
      this.q("#promptInput").addEventListener("keydown", (e) => {
        if (e.ctrlKey && e.key === "Enter")
          this.addPrompts();
      });
      this.q("#btnTxt").addEventListener("click", () => this.q("#fTxt").click());
      this.q("#btnCsv").addEventListener("click", () => this.q("#fCsv").click());
      this.q("#fTxt").addEventListener("change", (e) => this.importTxt(e));
      this.q("#fCsv").addEventListener("change", (e) => this.importCsv(e));
      // char section removed
      this.qAll(".sfield").forEach((el) => el.addEventListener("change", () => this.saveSettingsFromUI()));
      this.q("#btnSave").addEventListener("click", () => this.saveSettingsFromUI());
      this.q("#btnCopyFailed").addEventListener("click", () => this.copyAllFailed());
      this.q("#btnClearFailed").addEventListener("click", async () => {
        await this.cSet({ failed: [] });
        this.failed = [];
        this.refreshFailed();
        this.updateFailBadge();
      });
      this.q("#btnClearLogs").addEventListener("click", async () => {
        await this.cSet({ logs: [] });
        this.logs = [];
        this.refreshLogs();
      });
    }
    // ─── MODE UI ──────────────────────────────────────────────────────────────
    applyModeUI() {
      const m = this.cfg.mode, mc = MODES[m], isVid = mc.isVideo;
      this.qAll(".mpill").forEach((p) => p.classList.toggle("active", p.dataset.mode === m));
      this.q("#rowDur").style.display = isVid ? "" : "none";
      this.q("#rowVMod").style.display = isVid ? "" : "none";
      // camera row removed
      this.q("#rowIMod").style.display = !isVid ? "" : "none";
      const opts = isVid ? ASPECT_VIDEO : ASPECT_IMAGE;
      const sel = this.q("#selAspect");
      sel.innerHTML = opts.map((o) => `<option value="${o}" ${this.cfg.aspectRatio === o ? "selected" : ""}>${o}</option>`).join("");
      // secChar removed
      // secAudio removed
      this.renderPromptList();
    }
    // ─── SETTINGS ─────────────────────────────────────────────────────────────
    populateSettings() {
      this.q("#selDur").innerHTML = DURATIONS.map((o) => `<option value="${o}" ${this.cfg.duration === o ? "selected" : ""}>${o}s</option>`).join("");
      this.q("#selVMod").innerHTML = VIDEO_MODELS.map((o) => `<option value="${o}"  ${this.cfg.videoModel === o ? "selected" : ""}>${o}</option>`).join("");
      this.q("#selIMod").innerHTML = IMAGE_MODELS.map((o) => `<option value="${o}"  ${this.cfg.imageModel === o ? "selected" : ""}>${o}</option>`).join("");
      // camera select removed
      this.q("#inpProject").value = this.cfg.projectName || "My Project";
      this.q("#inpDelayMin").value = this.cfg.delayMin ?? 15;
      this.q("#inpDelayMax").value = this.cfg.delayMax ?? 25;
      this.q("#selRetry").value = this.cfg.maxRetry ?? 3;
    }
    async saveSettingsFromUI() {
      this.cfg = {
        ...this.cfg,
        aspectRatio: this.q("#selAspect")?.value || this.cfg.aspectRatio,
        duration: this.q("#selDur")?.value || "4",
        videoModel: this.q("#selVMod")?.value || "Dreamina Seedance 2.0 Fast",
        imageModel: this.q("#selIMod")?.value || "Seedream 4.1",
                projectName: this.q("#inpProject")?.value.trim() || "My Project",
        delayMin: parseInt(this.q("#inpDelayMin")?.value || 15),
        delayMax: parseInt(this.q("#inpDelayMax")?.value || 25),
        maxRetry: parseInt(this.q("#selRetry")?.value || 3)
      };
      await this.saveCfg();
      this.toast("Settings saved \u2713", "success");
    }
    async saveCfg() {
      await this.cSet({ cfg: this.cfg });
    }
    // ─── CHARACTER IMAGES ─────────────────────────────────────────────────────
    renderCharImages() {
      const wrap = this.q("#charList");
      if (!wrap)
        return;
      if (!this.charImages.length) {
        wrap.innerHTML = `<div class="empty-state"><div class="empty-icon">\u{1F5BC}</div><p>No character images yet</p><span>Add images then click Auto Assign</span></div>`;
        return;
      }
      wrap.innerHTML = this.charImages.map((img, i) => `
      <div class="char-card">
        <img class="char-thumb" src="data:${img.mimeType};base64,${img.data}">
        <div class="char-info">
          <div class="char-badge">Char #${i + 1}</div>
          <div class="char-name">${esc(img.name)}</div>
        </div>
        <button class="icon-del" data-id="${img.id}">\u2715</button>
      </div>`).join("");
      wrap.querySelectorAll(".icon-del").forEach((btn) => btn.addEventListener("click", () => {
        this.charImages = this.charImages.filter((x) => x.id !== btn.dataset.id);
        this.renderCharImages();
      }));
    }
    autoAssign() {
      if (!this.charImages.length) {
        this.toast("Add character images first", "warn");
        return;
      }
      if (!this.promptList.length) {
        this.toast("Add prompts first", "warn");
        return;
      }
      this.promptList.forEach((p, i) => {
        p.images = [this.charImages[i % this.charImages.length]];
      });
      this.renderPromptList();
      this.toast(`\u26A1 Assigned ${this.charImages.length} image(s) to ${this.promptList.length} prompts`, "success");
    }
    // ─── PROMPT LIST ──────────────────────────────────────────────────────────
    renderPromptList() {
      const wrap = this.q("#promptCards");
      if (!wrap)
        return;
      const mc = MODES[this.cfg.mode];
      if (!this.promptList.length) {
        wrap.innerHTML = `<div class="empty-state">
        <div class="empty-icon">\u270D\uFE0F</div>
        <p>No prompts yet</p>
        <span>Type below and press <b>+ Add</b> or <b>Ctrl+Enter</b></span>
      </div>`;
        return;
      }
      wrap.innerHTML = this.promptList.map((p, i) => `
      <div class="pcard">
        <div class="pcard-head">
          <div class="pcard-num">${i + 1}</div>
          <div class="pcard-body">
            <div class="pcard-text">${esc(p.text.substring(0, 120))}${p.text.length > 120 ? "\u2026" : ""}</div>
            ${mc.needImg ? `
            <div class="file-row">
              <span class="file-label">\u{1F5BC} Image</span>
              ${p.images.length === 0 ? `<label class="chip-add">+ Add<input type="file" accept="image/*" multiple data-pid="${p.id}" data-ft="image" class="hid"></label>` : p.images.map((img, ii) => `
                  <div class="file-chip">
                    <img class="chip-img" src="data:${img.mimeType};base64,${img.data}">
                    <span class="chip-name">${img.name.substring(0, 14)}</span>
                    <button class="chip-x" data-pid="${p.id}" data-ft="image" data-ii="${ii}">\u2715</button>
                  </div>`).join("") + `<label class="chip-add">+<input type="file" accept="image/*" multiple data-pid="${p.id}" data-ft="image" class="hid"></label>`}
            </div>` : ""}

          </div>
          <button class="pcard-del" data-id="${p.id}">\u2715</button>
        </div>
      </div>`).join("");
      wrap.querySelectorAll(".pcard-del").forEach((btn) => btn.addEventListener("click", () => {
        this.promptList = this.promptList.filter((p) => p.id !== btn.dataset.id);
        this.renderPromptList();
      }));
      wrap.querySelectorAll(".hid").forEach((inp) => inp.addEventListener("change", async (e) => {
        const pid = inp.dataset.pid, ft = inp.dataset.ft;
        const item = this.promptList.find((p) => p.id === pid);
        if (!item)
          return;
        for (const f of e.target.files) {
          const data = await this.f2b64(f);
          const fd = { id: uid(), name: f.name, data, mimeType: f.type };
          if (ft === "image")
            item.images.push(fd);
          else if (ft === "audio")
            item.audio = fd;
          else if (ft === "videoRef")
            item.videoRef = fd;
          else if (ft === "styleRef")
            item.styleRef = fd;
        }
        this.renderPromptList();
        inp.value = "";
      }));
      wrap.querySelectorAll(".chip-x").forEach((btn) => btn.addEventListener("click", () => {
        const item = this.promptList.find((p) => p.id === btn.dataset.pid);
        if (!item)
          return;
        const ft = btn.dataset.ft, ii = parseInt(btn.dataset.ii ?? "-1");
        if (ft === "image" && ii >= 0)
          item.images.splice(ii, 1);
        else if (ft === "audio")
          item.audio = null;
        else if (ft === "videoRef")
          item.videoRef = null;
        else if (ft === "styleRef")
          item.styleRef = null;
        this.renderPromptList();
      }));
    }
    addPrompts() {
      const ta = this.q("#promptInput"), raw = ta.value.trim();
      if (!raw) {
        this.toast("Type a prompt first", "warn");
        return;
      }
      const chunks = raw.split(/\n\s*\n/).map((s) => s.trim()).filter(Boolean);
      chunks.forEach((text) => this.promptList.push({ id: uid(), text, images: [], audio: null, videoRef: null, styleRef: null }));
      ta.value = "";
      this.renderPromptList();
      this.toast(`Added ${chunks.length} prompt${chunks.length > 1 ? "s" : ""}`, "success");
    }
    async importTxt(e) {
      const f = e.target.files[0];
      if (!f)
        return;
      const chunks = (await f.text()).split(/\n\s*\n/).map((s) => s.trim()).filter(Boolean);
      chunks.forEach((text) => this.promptList.push({ id: uid(), text, images: [], audio: null, videoRef: null, styleRef: null }));
      this.renderPromptList();
      this.toast(`Imported ${chunks.length} prompts`, "success");
      e.target.value = "";
    }
    async importCsv(e) {
      const f = e.target.files[0];
      if (!f)
        return;
      const lines = (await f.text()).split("\n").map((l) => l.replace(/^"|"$/g, "").trim()).filter(Boolean);
      let c = 0;
      lines.forEach((text) => {
        if (text && text.toLowerCase() !== "prompt") {
          this.promptList.push({ id: uid(), text, images: [], audio: null, videoRef: null, styleRef: null });
          c++;
        }
      });
      this.renderPromptList();
      this.toast(`Imported ${c} prompts`, "success");
      e.target.value = "";
    }
    f2b64(file) {
      return new Promise((r) => {
        const fr = new FileReader();
        fr.onload = (e) => r(e.target.result.split(",")[1]);
        fr.readAsDataURL(file);
      });
    }
    // ─── RUN ──────────────────────────────────────────────────────────────────
    async doRun() {
      if (!this.promptList.length) {
        this.toast("Add at least one prompt first", "warn");
        return;
      }
      await this.saveSettingsFromUI();
      const safeProject = (this.cfg.projectName || "My-Project").replace(/[^a-zA-Z0-9_\- ]/g, "_");
      const settings = { ...this.cfg, saveFolder: `Auto-Seedance/${safeProject}` };
      await this.msg(MSG.START_QUEUE, { queue: this.promptList.map((p) => ({ text: p.text, images: p.images, audio: p.audio, videoRef: p.videoRef, styleRef: p.styleRef })), settings });
      this.q("#progWrap").style.display = "";
      this.toast("Queue started \u{1F680}", "success");
    }
    async doPause() {
      if (this.bgState.status === "running")
        await this.msg(MSG.PAUSE_QUEUE);
      else if (this.bgState.status === "paused")
        await this.msg(MSG.RESUME_QUEUE);
    }
    async doStop() {
      await this.msg(MSG.STOP_QUEUE);
    }
    async doClear() {
      await this.msg(MSG.CLEAR_QUEUE);
      this.q("#progWrap").style.display = "none";
    }
    // ─── REFRESH ──────────────────────────────────────────────────────────────
    refreshAll() {
      this.refreshRunBar();
      this.refreshQueueList();
      this.refreshFailed();
      this.updateFailBadge();
      if (this.activeTab === "logs")
        this.refreshLogs();
    }
    refreshRunBar() {
      const st = this.bgState.status, running = st === "running", paused = st === "paused";
      const rb = this.q("#btnRun"), pb = this.q("#btnPause");
      if (rb) {
        rb.disabled = running || paused;
        rb.textContent = running ? "Running\u2026" : paused ? "Paused" : "\u25B6 Run";
      }
      if (pb)
        pb.textContent = paused ? "\u25B6 Resume" : "\u23F8 Pause";
      const pw = this.q("#progWrap");
      if (pw && this.bgState.total > 0) {
        pw.style.display = "";
        const pct = Math.round((this.bgState.idx || 0) / this.bgState.total * 100);
        const bar = this.q("#progBar");
        if (bar)
          bar.style.width = pct + "%";
        const lbl = this.q("#progLabel");
        if (lbl) {
          const running = (this.bgState.queue || []).filter(p => p.status === "running").length;
          const current = (this.bgState.idx || 0) + (running > 0 ? 1 : 0);
          lbl.textContent = `${current} of ${this.bgState.total} prompt${this.bgState.total !== 1 ? "s" : ""}`;
        }
        const sl = this.q("#progStat");
        if (sl)
          sl.textContent = st.toUpperCase();
      }
    }
    refreshQueueList() {
      const el = this.q("#qList");
      if (!el)
        return;
      const q = this.bgState.queue || [];
      if (!q.length) {
        el.innerHTML = "";
        return;
      }
      el.innerHTML = q.map((p) => `
      <div class="qi">
        <span class="qi-dot ${p.status}"></span>
        <span class="qi-txt">${esc(p.text?.substring(0, 55) || "")}${(p.text?.length || 0) > 55 ? "\u2026" : ""}</span>
        <span class="qi-badge ${p.status}">${p.status}</span>
      </div>`).join("");
    }
    refreshFailed() {
      const el = this.q("#failList");
      if (!el)
        return;
      if (!this.failed.length) {
        el.innerHTML = `<div class="empty-state"><div class="empty-icon">\u2705</div><p>No failed prompts</p><span>All prompts completed successfully</span></div>`;
        return;
      }
      el.innerHTML = this.failed.map((f, i) => `
      <div class="fail-card">
        <div class="fail-text">${esc(f.prompt)}</div>
        <div class="fail-meta">
          <span class="fail-reason">${esc(f.reason || "Unknown error")}</span>
          <span class="fail-time">${new Date(f.ts).toLocaleTimeString()}</span>
        </div>
        <button class="btn-copy-one" data-i="${i}">Copy</button>
      </div>`).join("");
      el.querySelectorAll(".btn-copy-one").forEach((btn) => btn.addEventListener("click", () => {
        navigator.clipboard.writeText(this.failed[btn.dataset.i].prompt);
        btn.textContent = "Copied!";
        setTimeout(() => btn.textContent = "Copy", 2e3);
      }));
    }
    refreshLogs() {
      const el = this.q("#logList");
      if (!el)
        return;
      if (!this.logs.length) {
        el.innerHTML = `<div class="empty-state"><div class="empty-icon">\u{1F4CB}</div><p>No logs yet</p><span>Logs appear when the queue runs</span></div>`;
        return;
      }
      el.innerHTML = this.logs.slice(0, 150).map((l) => `
      <div class="log-row ${l.type || "info"}">
        <span class="log-time">${new Date(l.ts).toLocaleTimeString()}</span>
        <span class="log-msg">${esc(l.message)}</span>
      </div>`).join("");
    }
    updateFailBadge() {
      const b = this.q("#failBadge");
      if (b) {
        b.textContent = this.failed.length;
        b.style.display = this.failed.length ? "" : "none";
      }
    }
    copyAllFailed() {
      if (!this.failed.length)
        return;
      navigator.clipboard.writeText(this.failed.map((f) => f.prompt).join("\n\n"));
      this.toast(`Copied ${this.failed.length} failed prompts`, "success");
    }
    toast(msg, type = "success") {
      const el = this.q("#toast");
      if (!el)
        return;
      el.textContent = msg;
      el.className = `toast show ${type}`;
      clearTimeout(this._tt);
      this._tt = setTimeout(() => el.className = "toast", 3e3);
    }
  };
  function uid() {
    return `_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }
  var HTML = `
<header class="hdr">
  <div class="hdr-brand">
    <div class="brand-logo">\u{1F331}</div>
    <div>
      <div class="brand-name">Auto Seedance</div>
      <div class="brand-sub">Dreamina Bulk Generator</div>
    </div>
  </div>
  <button class="btn-outline" id="btnOpen">\u2197 Open Dreamina</button>
</header>

<div class="mode-strip">
  <button class="mpill" data-mode="t2v">\u{1F3AC}<span>Text\u2192Video</span></button>
  <button class="mpill" data-mode="t2i">\u{1F5BC}<span>Text\u2192Image</span></button>
  <button class="mpill" data-mode="i2v">\u{1F39E}<span>Image\u2192Video</span></button>
</div>

<div class="qsbar">
  <div class="qs-group">
    <label class="qs-lbl">Ratio</label>
    <select class="qs-sel sfield" id="selAspect"></select>
  </div>
  <div class="qs-group" id="rowDur">
    <label class="qs-lbl">Duration</label>
    <select class="qs-sel sfield" id="selDur"></select>
  </div>
  <div class="qs-group" id="rowVMod">
    <label class="qs-lbl">Model</label>
    <select class="qs-sel sfield" id="selVMod"></select>
  </div>
  <div class="qs-group" id="rowIMod" style="display:none">
    <label class="qs-lbl">Model</label>
    <select class="qs-sel sfield" id="selIMod"></select>
  </div>
</div>

<nav class="tabbar">
  <button class="tab active" data-t="queue">Queue</button>
  <button class="tab" data-t="settings">Settings</button>
  <button class="tab" data-t="failed">Failed<span class="fail-badge" id="failBadge" style="display:none">0</span></button>
  <button class="tab" data-t="logs">Logs</button>
</nav>

<div class="pane active" id="p-queue">

  <div class="card">
    <div class="card-hdr">
      <div class="card-title">\u{1F4AC} Prompts</div>
      <div class="hdr-actions">
        <button class="btn-sm" id="btnTxt">\u{1F4C4} .txt</button>
        <button class="btn-sm" id="btnCsv">\u{1F4CA} .csv</button>
        <input type="file" id="fTxt" accept=".txt" hidden>
        <input type="file" id="fCsv" accept=".csv" hidden>
      </div>
    </div>

    <div id="promptCards" class="prompt-list"></div>

    <div class="add-row">
      <textarea id="promptInput" class="prompt-ta" placeholder="Type prompts here\u2026&#10;Separate multiple prompts with a blank line.&#10;Ctrl+Enter to add quickly."></textarea>
      <button class="btn-add" id="btnAdd">+ Add</button>
    </div>
  </div>

  <div id="progWrap" class="prog-card" style="display:none">
    <div class="prog-header">
      <span class="prog-label" id="progLabel">Ready</span>
      <span class="prog-badge" id="progStat">IDLE</span>
    </div>
    <div class="prog-track"><div class="prog-fill" id="progBar" style="width:0%"></div></div>
    <div class="prog-msg" id="progText">Waiting\u2026</div>
  </div>

  <div id="qList" class="q-list"></div>
  <div id="toast" class="toast"></div>

  <div class="ctrl-bar">
    <div class="ctrl-group">
      <button class="ctrl-btn" id="btnStop">\u23F9</button>
      <button class="ctrl-btn" id="btnPause">\u23F8 Pause</button>
      <button class="ctrl-btn" id="btnSkip">\u23ED</button>
      <button class="ctrl-btn red" id="btnClear">\u2715 Clear</button>
    </div>
    <button class="btn-run" id="btnRun">\u25B6 Run</button>
  </div>
</div>

<div class="pane" id="p-settings">
  <div class="card">
    <div class="card-hdr"><div class="card-title">\u{1F4C1} Project Folder</div></div>
    <div class="srow">
      <label class="slabel">Project Name</label>
      <input class="sinp sfield" type="text" id="inpProject" placeholder="My Project">
    </div>
    <p class="hint" style="padding:0 0 4px">Saves to: <code>Downloads/Auto-Seedance/<em>Project Name</em>/</code></p>
  </div>

  <div class="card">
    <div class="card-hdr"><div class="card-title">\u2699\uFE0F Automation</div></div>
    <div class="srow">
      <label class="slabel">Delay Between Prompts</label>
      <div class="sinp-row">
        <input class="sinp sfield narrow" type="number" id="inpDelayMin" min="5" max="300" value="15">
        <span class="sdash">\u2013</span>
        <input class="sinp sfield narrow" type="number" id="inpDelayMax" min="5" max="300" value="25">
        <span class="sunit">sec</span>
      </div>
    </div>
    <div class="srow">
      <label class="slabel">Max Retries on Fail</label>
      <select class="ssel sfield" id="selRetry">
        <option value="1">1</option><option value="2">2</option>
        <option value="3" selected>3</option><option value="5">5</option>
      </select>
    </div>
  </div>

  <button class="btn-save" id="btnSave">\u{1F4BE} Save Settings</button>
</div>

<div class="pane" id="p-failed">
  <div class="pane-hdr">
    <span class="pane-title">Failed Prompts</span>
    <div class="hdr-actions">
      <button class="btn-sm" id="btnCopyFailed">\u{1F4CB} Copy All</button>
      <button class="btn-sm red" id="btnClearFailed">\u{1F5D1} Clear</button>
    </div>
  </div>
  <p class="hint" style="margin-bottom:10px">Copy these prompts and re-add them to retry.</p>
  <div id="failList" class="fail-list"></div>
</div>

<div class="pane" id="p-logs">
  <div class="pane-hdr">
    <span class="pane-title">Debug Logs</span>
    <button class="btn-sm red" id="btnClearLogs">\u{1F5D1} Clear</button>
  </div>
  <div id="logList" class="log-list"></div>
</div>

<footer class="footer">
  <span>Auto Seedance v1.0</span>
  <span class="footer-dot">\xB7</span>
  <span>Dreamina Only</span>
</footer>`;
  var CSS = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
html,body{background:#FAF8F5;font-family:'Inter',system-ui,sans-serif;font-size:13px;line-height:1.5;color:#1F2937;overflow-x:hidden}
.app{display:flex;flex-direction:column;min-height:100vh;background:#FAF8F5}

/* \u2500\u2500 HEADER \u2500\u2500 */
.hdr{display:flex;align-items:center;justify-content:space-between;padding:12px 16px;
  background:#FFFFFF;border-bottom:1px solid #E5E7EB;
  box-shadow:0 1px 3px rgba(0,0,0,.06)}
.hdr-brand{display:flex;align-items:center;gap:10px}
.brand-logo{width:34px;height:34px;background:linear-gradient(135deg,#F59E0B,#FB7185);
  border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:17px;
  box-shadow:0 2px 8px rgba(245,158,11,.3);flex-shrink:0}
.brand-name{font-size:14px;font-weight:800;color:#1F2937;letter-spacing:-.3px;line-height:1.2}
.brand-sub{font-size:10px;color:#9CA3AF;font-weight:500}
.btn-outline{padding:6px 12px;background:#FFFFFF;border:1.5px solid #E5E7EB;border-radius:8px;
  color:#6B7280;font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;
  transition:all .15s;white-space:nowrap}
.btn-outline:hover{border-color:#F59E0B;color:#F59E0B;background:#FFFBF0}

/* \u2500\u2500 MODE STRIP \u2500\u2500 */
.mode-strip{display:flex;gap:5px;padding:10px 14px;background:#FFFFFF;
  border-bottom:1px solid #E5E7EB;flex-wrap:wrap}
.mpill{display:flex;align-items:center;gap:5px;padding:6px 11px;
  background:#F9FAFB;border:1.5px solid #E5E7EB;border-radius:20px;
  color:#6B7280;font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;
  transition:all .18s;white-space:nowrap}
.mpill span{font-size:11px}
.mpill.active{background:linear-gradient(135deg,#FEF3C7,#FFE4E6);
  border-color:#F59E0B;color:#92400E;
  box-shadow:0 1px 6px rgba(245,158,11,.2)}
.mpill:hover:not(.active){border-color:#D1D5DB;color:#374151;background:#F3F4F6}

/* \u2500\u2500 QUICK SETTINGS BAR \u2500\u2500 */
.qsbar{display:flex;gap:8px;padding:8px 14px;background:#FFFFFF;
  border-bottom:1px solid #E5E7EB;flex-wrap:wrap;align-items:flex-end}
.qs-group{display:flex;flex-direction:column;gap:3px;min-width:0}
.qs-lbl{font-size:9px;font-weight:700;color:#9CA3AF;text-transform:uppercase;letter-spacing:.1em}
.qs-sel{padding:5px 7px;background:#F9FAFB;border:1.5px solid #E5E7EB;border-radius:7px;
  color:#374151;font-size:11px;font-weight:500;cursor:pointer;font-family:inherit;max-width:110px;
  transition:border-color .15s}
.qs-sel:focus{outline:none;border-color:#F59E0B;background:#FFFBF0}

/* \u2500\u2500 TABS \u2500\u2500 */
.tabbar{display:flex;background:#FFFFFF;border-bottom:1px solid #E5E7EB;padding:0 12px}
.tab{flex:1;padding:9px 4px;background:none;border:none;border-bottom:2px solid transparent;
  color:#9CA3AF;font-size:10px;font-weight:700;cursor:pointer;font-family:inherit;
  text-transform:uppercase;letter-spacing:.07em;display:flex;align-items:center;justify-content:center;
  gap:5px;transition:all .2s}
.tab.active{color:#F59E0B;border-bottom-color:#F59E0B}
.tab:hover:not(.active){color:#6B7280}
.fail-badge{background:#FB7185;color:#fff;font-size:9px;padding:1px 6px;border-radius:10px;font-weight:700}

/* \u2500\u2500 PANES \u2500\u2500 */
.pane{display:none;flex-direction:column;gap:10px;padding:12px;overflow-y:auto;flex:1}
.pane.active{display:flex}
.pane-hdr{display:flex;align-items:center;justify-content:space-between}
.pane-title{font-size:13px;font-weight:700;color:#1F2937}

/* \u2500\u2500 CARD \u2500\u2500 */
.card{background:#FFFFFF;border:1px solid #E5E7EB;border-radius:12px;padding:12px;
  box-shadow:0 1px 4px rgba(0,0,0,.05)}
.card-hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.card-title{font-size:11px;font-weight:700;color:#374151;letter-spacing:.02em}
.hdr-actions{display:flex;gap:5px;align-items:center}
.hint{font-size:10px;color:#9CA3AF;line-height:1.5;margin-top:6px}

/* \u2500\u2500 BUTTONS \u2500\u2500 */
.btn-sm{padding:5px 10px;background:#F9FAFB;border:1.5px solid #E5E7EB;border-radius:7px;
  color:#6B7280;font-size:11px;font-weight:600;cursor:pointer;font-family:inherit;
  white-space:nowrap;transition:all .15s}
.btn-sm:hover{border-color:#D1D5DB;color:#374151;background:#F3F4F6}
.btn-sm.red:hover{border-color:#FB7185;color:#E11D48}
.btn-primary-sm{padding:5px 10px;background:linear-gradient(135deg,#F59E0B,#FB7185);border:none;
  border-radius:7px;color:#fff;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;
  white-space:nowrap;box-shadow:0 1px 6px rgba(245,158,11,.35);transition:all .15s}
.btn-primary-sm:hover{opacity:.9;box-shadow:0 2px 10px rgba(245,158,11,.45)}

/* \u2500\u2500 CHARACTER IMAGES \u2500\u2500 */
.char-card{display:flex;align-items:center;gap:9px;padding:8px;background:#F9FAFB;
  border:1px solid #E5E7EB;border-radius:9px;margin-bottom:5px}
.char-thumb{width:42px;height:42px;object-fit:cover;border-radius:7px;border:2px solid #E5E7EB;flex-shrink:0}
.char-info{flex:1;min-width:0}
.char-badge{font-size:10px;font-weight:700;color:#F59E0B;margin-bottom:2px}
.char-name{font-size:11px;color:#6B7280;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.icon-del{background:none;border:none;color:#D1D5DB;cursor:pointer;font-size:13px;font-weight:600;
  padding:2px 5px;border-radius:5px;transition:all .15s}
.icon-del:hover{background:#FEE2E2;color:#E11D48}

/* \u2500\u2500 EMPTY STATE \u2500\u2500 */
.empty-state{display:flex;flex-direction:column;align-items:center;justify-content:center;
  padding:28px 16px;gap:6px;text-align:center}
.empty-icon{font-size:30px;opacity:.35;margin-bottom:2px}
.empty-state p{font-size:13px;font-weight:600;color:#6B7280}
.empty-state span{font-size:11px;color:#9CA3AF}
.empty-state b{color:#F59E0B}

/* \u2500\u2500 PROMPT LIST \u2500\u2500 */
.prompt-list{display:flex;flex-direction:column;gap:6px;max-height:290px;overflow-y:auto;margin-bottom:10px}
.prompt-list::-webkit-scrollbar{width:4px}
.prompt-list::-webkit-scrollbar-thumb{background:#E5E7EB;border-radius:2px}

/* \u2500\u2500 PROMPT CARD \u2500\u2500 */
.pcard{background:#F9FAFB;border:1.5px solid #E5E7EB;border-radius:10px;padding:10px;
  transition:all .15s}
.pcard:hover{border-color:#F59E0B;box-shadow:0 1px 6px rgba(245,158,11,.12)}
.pcard-head{display:flex;align-items:flex-start;gap:9px}
.pcard-num{width:22px;height:22px;background:linear-gradient(135deg,#F59E0B,#FB7185);
  border-radius:6px;display:flex;align-items:center;justify-content:center;
  font-size:10px;font-weight:800;color:#fff;flex-shrink:0;margin-top:1px}
.pcard-body{flex:1;min-width:0}
.pcard-text{font-size:12px;color:#374151;line-height:1.45;word-break:break-word;margin-bottom:6px}
.pcard-del{background:none;border:none;color:#D1D5DB;cursor:pointer;font-size:13px;font-weight:600;
  padding:2px 5px;border-radius:5px;flex-shrink:0;transition:all .15s}
.pcard-del:hover{background:#FEE2E2;color:#E11D48}

/* \u2500\u2500 FILE ROWS \u2500\u2500 */
.file-row{display:flex;flex-wrap:wrap;gap:5px;align-items:center;margin-top:5px;
  padding-top:5px;border-top:1px solid #E5E7EB}
.file-label{font-size:10px;font-weight:600;color:#9CA3AF;width:100%;margin-bottom:2px}
.file-chip{display:flex;align-items:center;gap:5px;background:#FFFFFF;border:1px solid #E5E7EB;
  border-radius:6px;padding:3px 7px;font-size:11px}
.chip-img{width:24px;height:24px;object-fit:cover;border-radius:4px;flex-shrink:0}
.chip-name{color:#6B7280;max-width:80px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px}
.chip-x{background:none;border:none;color:#D1D5DB;cursor:pointer;font-size:11px;padding:0 2px;transition:color .15s}
.chip-x:hover{color:#E11D48}
.chip-add{padding:4px 9px;background:#FFFFFF;border:1.5px dashed #D1D5DB;border-radius:6px;
  color:#9CA3AF;font-size:10px;cursor:pointer;font-weight:600;transition:all .15s;display:inline-flex;align-items:center}
.chip-add:hover{border-color:#F59E0B;color:#F59E0B;background:#FFFBF0}
.hid{display:none}

/* \u2500\u2500 ADD ROW \u2500\u2500 */
.add-row{display:flex;gap:8px;align-items:flex-end}
.prompt-ta{flex:1;min-height:68px;padding:10px;background:#F9FAFB;border:1.5px solid #E5E7EB;
  border-radius:9px;color:#1F2937;font-size:12px;resize:vertical;font-family:inherit;line-height:1.5;
  transition:border-color .15s}
.prompt-ta:focus{outline:none;border-color:#F59E0B;background:#FFFBF0;box-shadow:0 0 0 3px rgba(245,158,11,.08)}
.prompt-ta::placeholder{color:#9CA3AF}
.btn-add{padding:10px 14px;background:linear-gradient(135deg,#F59E0B,#FB7185);border:none;
  border-radius:9px;color:#fff;font-size:12px;font-weight:700;cursor:pointer;font-family:inherit;
  white-space:nowrap;align-self:flex-end;box-shadow:0 2px 8px rgba(245,158,11,.35);transition:all .15s}
.btn-add:hover{opacity:.92;box-shadow:0 3px 12px rgba(245,158,11,.45);transform:translateY(-1px)}

/* \u2500\u2500 PROGRESS \u2500\u2500 */
.prog-card{background:#FFFFFF;border:1px solid #E5E7EB;border-radius:12px;padding:14px;
  box-shadow:0 1px 4px rgba(0,0,0,.05)}
.prog-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:9px}
.prog-label{font-size:12px;font-weight:600;color:#374151}
.prog-badge{font-size:9px;font-weight:700;color:#F59E0B;background:#FEF3C7;
  padding:3px 8px;border-radius:99px;letter-spacing:.07em}
.prog-track{height:5px;background:#F3F4F6;border-radius:99px;overflow:hidden;margin-bottom:8px}
.prog-fill{height:100%;background:linear-gradient(90deg,#F59E0B,#FB7185);border-radius:99px;transition:width .6s ease}
.prog-msg{font-size:11px;color:#9CA3AF;font-family:'Courier New',monospace}

/* \u2500\u2500 QUEUE LIST \u2500\u2500 */
.q-list{display:flex;flex-direction:column;gap:3px;max-height:220px;overflow-y:auto}
.qi{display:flex;align-items:center;gap:8px;font-size:11px;padding:5px 8px;
  background:#FFFFFF;border:1px solid #F3F4F6;border-radius:8px}
.qi-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}
.qi-dot.pending{background:#D1D5DB}
.qi-dot.running{background:#F59E0B;animation:blink 1s infinite;box-shadow:0 0 6px rgba(245,158,11,.5)}
.qi-dot.done{background:#10B981}
.qi-dot.failed{background:#FB7185}
.qi-dot.skipped{background:#D1D5DB}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
.qi-txt{flex:1;color:#6B7280;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.qi-badge{font-size:9px;font-weight:700;padding:2px 7px;border-radius:99px;letter-spacing:.05em;flex-shrink:0}
.qi-badge.running{background:#FEF3C7;color:#92400E}
.qi-badge.done{background:#D1FAE5;color:#065F46}
.qi-badge.failed{background:#FFE4E6;color:#9F1239}
.qi-badge.pending{background:#F3F4F6;color:#6B7280}

/* \u2500\u2500 TOAST \u2500\u2500 */
.toast{position:sticky;bottom:0;padding:10px 14px;border-radius:10px;font-size:12px;font-weight:600;
  opacity:0;transform:translateY(8px);transition:all .25s;pointer-events:none}
.toast.show{opacity:1;transform:none}
.toast.show.success{background:#D1FAE5;border:1px solid #6EE7B7;color:#065F46}
.toast.show.warn{background:#FEF3C7;border:1px solid #FCD34D;color:#92400E}
.toast.show.error{background:#FFE4E6;border:1px solid #FDA4AF;color:#9F1239}

/* \u2500\u2500 CONTROLS \u2500\u2500 */
.ctrl-bar{display:flex;align-items:center;justify-content:space-between;gap:7px;margin-top:2px}
.ctrl-group{display:flex;gap:5px}
.ctrl-btn{height:34px;padding:0 11px;background:#FFFFFF;border:1.5px solid #E5E7EB;
  border-radius:8px;color:#6B7280;font-size:12px;cursor:pointer;font-family:inherit;
  white-space:nowrap;font-weight:500;transition:all .15s}
.ctrl-btn:hover{border-color:#D1D5DB;color:#374151;background:#F9FAFB}
.ctrl-btn.red:hover{border-color:#FB7185;color:#E11D48;background:#FFF1F2}
.btn-run{height:34px;padding:0 22px;background:linear-gradient(135deg,#F59E0B,#FB7185);
  border:none;border-radius:8px;color:#fff;font-size:13px;font-weight:700;cursor:pointer;
  font-family:inherit;box-shadow:0 2px 12px rgba(245,158,11,.35);transition:all .18s;white-space:nowrap}
.btn-run:hover:not(:disabled){box-shadow:0 4px 18px rgba(245,158,11,.5);transform:translateY(-1px)}
.btn-run:disabled{opacity:.45;cursor:not-allowed;box-shadow:none;transform:none}

/* \u2500\u2500 SETTINGS \u2500\u2500 */
.srow{display:flex;align-items:center;justify-content:space-between;padding:9px 0;
  border-bottom:1px solid #F3F4F6;gap:10px}
.srow:last-child{border:none}
.slabel{font-size:12px;color:#374151;font-weight:500;flex-shrink:0}
.sinp{padding:6px 9px;background:#F9FAFB;border:1.5px solid #E5E7EB;border-radius:7px;
  color:#1F2937;font-size:12px;font-family:inherit;transition:all .15s;width:150px}
.sinp:focus{outline:none;border-color:#F59E0B;background:#FFFBF0;box-shadow:0 0 0 3px rgba(245,158,11,.08)}
.sinp.narrow{width:52px;text-align:center;font-family:'Courier New',monospace}
.sinp-row{display:flex;align-items:center;gap:5px}
.sdash{color:#D1D5DB;font-size:12px}
.sunit{font-size:11px;color:#9CA3AF}
.ssel{padding:6px 9px;background:#F9FAFB;border:1.5px solid #E5E7EB;border-radius:7px;
  color:#1F2937;font-size:12px;font-family:inherit;transition:border-color .15s}
.ssel:focus{outline:none;border-color:#F59E0B}
.btn-save{width:100%;padding:11px;background:linear-gradient(135deg,#F59E0B,#FB7185);
  border:none;border-radius:9px;color:#fff;font-size:13px;font-weight:700;cursor:pointer;
  font-family:inherit;box-shadow:0 2px 10px rgba(245,158,11,.3);transition:all .15s;margin-top:4px}
.btn-save:hover{opacity:.92;box-shadow:0 4px 16px rgba(245,158,11,.45);transform:translateY(-1px)}
code{background:#F3F4F6;border-radius:4px;padding:1px 5px;font-size:10px;color:#6B7280;font-family:'Courier New',monospace}
em{color:#F59E0B;font-style:normal;font-weight:600}

/* \u2500\u2500 FAILED \u2500\u2500 */
.fail-list{display:flex;flex-direction:column;gap:8px;flex:1;overflow-y:auto}
.fail-card{background:#FFFFFF;border:1.5px solid #FFE4E6;border-radius:10px;padding:11px;position:relative;
  box-shadow:0 1px 4px rgba(251,113,133,.08)}
.fail-text{font-size:11px;color:#374151;white-space:pre-wrap;word-break:break-word;margin-bottom:7px;line-height:1.5}
.fail-meta{display:flex;align-items:center;gap:8px}
.fail-reason{font-size:10px;color:#FB7185;font-weight:600}
.fail-time{font-size:10px;color:#9CA3AF}
.btn-copy-one{position:absolute;top:9px;right:9px;padding:4px 9px;background:#F9FAFB;
  border:1.5px solid #E5E7EB;border-radius:6px;color:#6B7280;font-size:10px;font-weight:600;
  cursor:pointer;font-family:inherit;transition:all .15s}
.btn-copy-one:hover{border-color:#F59E0B;color:#F59E0B;background:#FFFBF0}

/* \u2500\u2500 LOGS \u2500\u2500 */
.log-list{display:flex;flex-direction:column;gap:2px;flex:1;overflow-y:auto}
.log-row{display:flex;gap:9px;font-size:10px;padding:5px 8px;border-radius:6px;
  background:#FFFFFF;border:1px solid #F3F4F6;font-family:'Courier New',monospace}
.log-time{color:#D1D5DB;flex-shrink:0;width:65px}
.log-msg{flex:1;word-break:break-all}
.log-row.info    .log-msg{color:#6B7280}
.log-row.success .log-msg{color:#059669}
.log-row.warn    .log-msg{color:#D97706}
.log-row.error   .log-msg{color:#E11D48}

/* \u2500\u2500 FOOTER \u2500\u2500 */
.footer{display:flex;align-items:center;justify-content:center;gap:6px;padding:8px;
  border-top:1px solid #E5E7EB;background:#FFFFFF;margin-top:auto;font-size:10px;color:#D1D5DB}
.footer-dot{color:#E5E7EB}
`;

  // src/sidebar/sidebar.js
  document.addEventListener("DOMContentLoaded", () => new App(document.getElementById("root")).init());
})();
